""" Database handler for SQLite and Azure SQL databases

This module manages databases for storing tracker information
"""

import os
from datetime import datetime
import logging

LOG = logging.getLogger(__name__)

# --- Configuration ---
DB_PATH = "tracker_data.db"

# --- Tracker info structure (for reference) ---
tracker_info = {
    "tracker_id": "",
    "longitude": 0.0,
    "latitude": 0.0,
    "battery": 0,
    "timestamp": "",
    "gw-rssi": -70,
    "gw-name": "",
    "gw-longitude": 0.0,
    "gw-latitude": 0.0,
    "gw-timestamp": ""
}


def init_db(db_path=DB_PATH, use_azure_sql=False):
    """
    Initialize the database (SQLite or Azure SQL).

    Args:
        db_path (str): Path to the SQLite database file (ignored for Azure SQL).
        use_azure_sql (bool): Whether to use Azure SQL instead of SQLite.

    Returns:
        Connection object or None on failure.
    """
    if use_azure_sql:
        return init_azure_sql_db()
    else:
        return init_sqlite_db(db_path)


def init_sqlite_db(db_path=DB_PATH):
    """
    Initialize the SQLite database.

    If the database file does not exist, it creates a new one and
    defines the schema for the 'tracker_data' table.

    Args:
        db_path (str): Path to the SQLite database file.

    Returns:
        sqlite3.Connection: SQLite connection object or None on failure.
    """
    try:
        import sqlite3
        db_exists = os.path.exists(db_path)
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()

        if not db_exists:
            # Create data table if the DB is new
            cursor.execute("""
                CREATE TABLE tracker_data (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    tracker_id TEXT,
                    longitude REAL,
                    latitude REAL,
                    battery INTEGER,
                    timestamp DATETIME,
                    gw_rssi INTEGER,
                    gw_name TEXT,
                    gw_longitude REAL,
                    gw_latitude REAL,
                    gw_timestamp DATETIME
                )
            """)
            conn.commit()

            # Create config table if the DB is new
            cursor.execute("""
                CREATE TABLE tracker_config (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    tracker_id TEXT,
                    tracker_name TEXT,
                    tracker_symbol TEXT,
                    tracker_symbol_color TEXT,
                    tracker_waypoint_max INTEGER,
                    tracker_waypoint_timeout INTEGER,
                    tracker_waypoint_color TEXT
                )
            """)
            conn.commit()

        return conn  # Return connection for reuse
    except Exception as e:
        LOG.error(f"SQLite error during init: {e}")
        return None


def init_azure_sql_db():
    """
    Initialize the Azure SQL database connection.

    Returns:
        pyodbc.Connection: Azure SQL connection object or None on failure.
    """
    try:
        import pyodbc

        # Get connection string from environment variables
        server = os.environ.get('AZURE_SQL_SERVER')
        database = os.environ.get('AZURE_SQL_DATABASE')
        username = os.environ.get('AZURE_SQL_USERNAME')
        password = os.environ.get('AZURE_SQL_PASSWORD')

        if not all([server, database, username, password]):
            raise ValueError("Missing Azure SQL connection environment variables")

        driver = '{ODBC Driver 18 for SQL Server}'
        connection_string = f'DRIVER={driver};SERVER={server};DATABASE={database};UID={username};PWD={password};Encrypt=yes;TrustServerCertificate=no;Connection Timeout=30;'

        conn = pyodbc.connect(connection_string)
        cursor = conn.cursor()

        # Check if tables exist, create if not
        cursor.execute("""
            IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='tracker_data' AND xtype='U')
            CREATE TABLE tracker_data (
                id INT IDENTITY(1,1) PRIMARY KEY,
                tracker_id NVARCHAR(255),
                longitude FLOAT,
                latitude FLOAT,
                battery INT,
                timestamp DATETIME2,
                gw_rssi INT,
                gw_name NVARCHAR(255),
                gw_longitude FLOAT,
                gw_latitude FLOAT,
                gw_timestamp DATETIME2
            )
        """)
        conn.commit()

        cursor.execute("""
            IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='tracker_config' AND xtype='U')
            CREATE TABLE tracker_config (
                id INT IDENTITY(1,1) PRIMARY KEY,
                tracker_id NVARCHAR(255),
                tracker_name NVARCHAR(255),
                tracker_symbol NVARCHAR(255),
                tracker_symbol_color NVARCHAR(255),
                tracker_waypoint_max INT,
                tracker_waypoint_timeout INT,
                tracker_waypoint_color NVARCHAR(255)
            )
        """)
        conn.commit()

        return conn
    except Exception as e:
        LOG.error(f"Azure SQL error during init: {e}")
        return None


def insert_tracker_info(conn, data):
    """
    Insert a row of tracker data into the database.

    Args:
        conn: Database connection object (SQLite or Azure SQL).
        data (dict): A dictionary containing tracker info.
    """
    try:
        # Check if it's an Azure SQL connection (has driver attribute) or SQLite
        if hasattr(conn, 'getinfo'):  # pyodbc connection
            cursor = conn.cursor()
            cursor.execute("""
                INSERT INTO tracker_data (
                    tracker_id, latitude, longitude, battery, timestamp,
                    gw_rssi, gw_name, gw_latitude, gw_longitude, gw_timestamp
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                data["tracker_id"],
                data["latitude"],
                data["longitude"],
                data["battery"],
                data["timestamp"],
                data["gw-rssi"],
                data["gw-name"],
                data["gw-latitude"],
                data["gw-longitude"],
                data["gw-timestamp"]
            ))
        else:  # SQLite connection
            cursor = conn.cursor()
            cursor.execute("""
                INSERT INTO tracker_data (
                    tracker_id, latitude, longitude, battery, timestamp,
                    gw_rssi, gw_name, gw_latitude, gw_longitude, gw_timestamp
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                data["tracker_id"],
                data["latitude"],
                data["longitude"],
                data["battery"],
                data["timestamp"],
                data["gw-rssi"],
                data["gw-name"],
                data["gw-latitude"],
                data["gw-longitude"],
                data["gw-timestamp"]
            ))
        conn.commit()
    except Exception as e:
        LOG.error(f"Database error during insert: {e}")


def get_tracker_data(conn, limit=1000):
    """
    Retrieve tracker data from the database.

    Args:
        conn: Database connection object.
        limit (int): Maximum number of records to return.

    Returns:
        list: List of tracker data dictionaries.
    """
    try:
        cursor = conn.cursor()
        if hasattr(conn, 'getinfo'):  # Azure SQL
            cursor.execute("SELECT TOP (?) tracker_id, latitude, longitude, battery, timestamp, gw_rssi, gw_name, gw_latitude, gw_longitude, gw_timestamp FROM tracker_data ORDER BY timestamp DESC", (limit,))
        else:  # SQLite
            cursor.execute("SELECT tracker_id, latitude, longitude, battery, timestamp, gw_rssi, gw_name, gw_latitude, gw_longitude, gw_timestamp FROM tracker_data ORDER BY timestamp DESC LIMIT ?", (limit,))

        columns = [column[0] for column in cursor.description]
        results = []
        for row in cursor.fetchall():
            results.append(dict(zip(columns, row)))

        return results
    except Exception as e:
        LOG.error(f"Database error during select: {e}")
        return []
